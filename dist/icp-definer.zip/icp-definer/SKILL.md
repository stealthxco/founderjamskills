---
name: icp-definer
description: Growth Track Part 1. Define your ideal customer using Jobs-to-be-Done, analyze how competitors are growing, and select 1-2 primary distribution channels. Writes icp_segment to config.json.
---

# ICP Definer

Define your beachhead customer, understand how competitors are acquiring customers, and select your distribution strategy. This is Growth Track Part 1.

## Overview

Three sequential sub-activities:

1. **ICP Definition via Jobs-to-be-Done** - Define 2-3 customer segments, score them, select one beachhead
2. **Competitive Growth Analysis** - Study 3-5 competitors' growth tactics to find content gaps and channel opportunities
3. **Distribution Strategy** - Evaluate channels against 4 criteria and commit to 1-2 primary channels

**Time estimate:** 75 minutes

## Setup

Read `config.json` if present. If missing, ask:
- Startup name, problem statement, target market, stage, business type
- Set `facilitated_mode` to `true` as default

## Process

### Sub-activity A: ICP Definition via Jobs-to-be-Done

**Introduce the framework:**

Jobs-to-be-Done (JTBD), developed by Clayton Christensen, focuses on the progress a customer is trying to make -- not their demographics. Customers "hire" a product to do a job.

**JTBD format:**
> "When [trigger event], I want to [motivation/job], so I can [desired outcome]."

**Example:**
> "When I am preparing for a quarterly business review and I do not have clean data, I want to pull all my metrics into one dashboard quickly, so I can walk in confident and not get caught flat-footed by a question I cannot answer."

**Step 1: Generate 2-3 ICP segments**

Ask the founder: "Who has the problem you're solving? Let's think about 2-3 different types of people or companies."

For each segment, craft a JTBD statement and build a profile:
- Demographic or firmographic (title, company size, industry, or geography)
- Psychographic triggers (what event or pressure makes this person urgently seek a solution)
- JTBD statement

**Step 2: Score each segment on 4 criteria (1-5 scale)**

| Criterion | What It Measures |
|-----------|-----------------|
| Pain Intensity | How much does this person suffer without a solution? (1 = inconvenience, 5 = crisis) |
| Willingness to Pay | Does this person have budget and urgency to buy? (1 = no budget/urgency, 5 = ready to pay now) |
| Reachability | Can you find and reach this segment efficiently? (1 = scattered, 5 = concentrated and findable) |
| Founder Advantage | Do you have unusual access, credibility, or insight into this segment? (1 = none, 5 = deep unfair advantage) |

**Step 3: Select the beachhead**

The beachhead is the ONE segment you own completely before expanding. A beachhead must be:
- Winnable with current resources
- Concentrated enough that they talk to each other
- Urgent -- they have a problem that requires solving now
- Resourced -- they have money or a clear path to monetization

Present the scoring table and recommend the highest-scoring segment as the beachhead. Let the founder confirm or override.

**Two-sided marketplace guidance:** If the startup is a marketplace, define supply and demand sides separately. Recommend starting with supply first -- "solve for the harder side first." Identify the 10-20 supply-side participants who will make the marketplace credible before scaling demand.

**ICP Red Flags -- check after beachhead selection:**

If any of these patterns appear, push the founder to sharpen their ICP before moving on:

- "We can help anyone" -- Push for specificity. A beachhead that includes everyone includes no one.
- "Both enterprise and SMB" -- Pick ONE to start. Serving both requires different sales motions, pricing, and support.
- No clear trigger event -- They don't know when buyers become buyers. Without a trigger, there is no urgency.
- Can't name a real person who fits -- The ICP is theoretical, not based on data. Push for a named individual or company.
- Targeting based on demographics not problems -- Flip to problem-first thinking. Demographics describe; problems motivate.

**ICP Validation Questions -- pressure-test the selected beachhead:**

After the founder selects a beachhead, run these five questions to validate the choice:

1. "Of your current customers or prospects, which one is the BEST fit and why?" -- If they can't name someone specific, the ICP may be aspirational rather than real.
2. "Who should we NOT target? Who's a bad customer?" -- Knowing who to exclude is as valuable as knowing who to pursue.
3. "How does this person find solutions today?" -- Reveals the channel strategy and competitive landscape.
4. "What would make them say no immediately?" -- Surfaces the real objections before the founder encounters them in the field.
5. "What's the buying process? Who else is involved?" -- Identifies whether the ICP has budget authority or needs to sell internally.

**Optional: Opportunity Segmentation Matrix**

If time allows, evaluate segments through an additional lens after JTBD scoring. Present this as optional:

| Segment | Future Focus | Just the Money | Worst Customers |
|---------|-------------|----------------|-----------------|
| Segment 1 | | | |
| Segment 2 | | | |
| Segment 3 | | | |

- **Future Focus:** Growing market, long-term potential, strategic value
- **Just the Money:** Immediate revenue opportunity, high willingness to pay now
- **Worst Customers:** Difficult to serve, low retention, high support cost -- avoid these

This matrix helps founders distinguish between segments that are attractive today vs. segments that build toward a defensible position.

**Facilitated mode challenge prompts:**
- "Who has this problem the worst, right now, and would pay the most to fix it?"
- "If you picked the wrong beachhead, how long until you'd know?"
- "Who has budget authority AND urgency to act -- not just frustration?"

**Output: ICP Card + Segment Comparison Table**

```
## ICP Card - [startup_name]

**Selected Beachhead:** [segment name]

**JTBD Statement:**
When [trigger event], I want to [motivation/job], so I can [desired outcome].

**Profile:**
- Who: [title, company size, industry or geography]
- Trigger: [specific event that creates urgency]
- Biggest pain: [what they lose sleep over]
- Current workaround: [what they do today without you]

**Why this beachhead:**
[1-2 sentence rationale based on scoring]
```

---

### Sub-activity B: Competitive Growth Analysis

**Introduce the activity:**

"Now let's look at how your competitors are actually growing -- not just who they are. We want to find the content gaps and channel opportunities they are leaving open."

**Step 1: Identify 3-5 competitors**

Include:
- 2-3 direct competitors (solving the same problem)
- 1-2 indirect competitors or status quo alternatives (what the ICP does today without you)

**Step 2: Growth tactic analysis per competitor**

For each competitor, analyze (use WebSearch if available, or ask the founder to provide intel):

| Growth Tactic | What to Look For |
|---------------|-----------------|
| Content strategy | What topics do they blog/podcast/video about? How frequently? |
| SEO approach | What keywords are they targeting? Are they going broad or niche? |
| Social presence | Which platforms? What type of content performs best for them? |
| Partnership ecosystem | Who do they integrate with or co-market with? |
| Paid acquisition signals | Are they running ads? What platforms? What offers? (Check Meta Ad Library, Google Ads Transparency) |

**Step 3: Content gap mapping**

After analyzing all competitors, identify:
- Topics your ICP cares about that NO competitor is covering well
- Questions your ICP asks that are not well-answered in existing content
- Angles your competitors avoid (often because they serve a broader or different audience)

**Dual-mode operation:**
- If WebSearch is available: run searches for each competitor's blog, LinkedIn page, and ad activity
- If founder-provided: ask the founder to describe what they know about each competitor's marketing

**Output: Competitive Growth Battle Cards**

For each competitor:

```
## Growth Battle Card: [Competitor Name]

**Their ICP:** [who they're targeting]
**Content focus:** [topics and formats they lead with]
**Primary channel:** [where they spend most acquisition effort]
**SEO approach:** [broad/niche, top keywords if known]
**Partnership strategy:** [integrations or co-marketing]
**Paid activity:** [yes/no, platforms, offer types if visible]
**Their gap:** [what they are NOT doing well that your ICP needs]
**Your opportunity:** [specific tactic to exploit their gap]
```

---

### Sub-activity C: Distribution Strategy

**Introduce the activity:**

"Based on who your ICP is and where competitors are NOT, let's pick 1-2 channels to own. The goal is to find the fastest path to 100 conversations without paid budget."

**Channel evaluation framework (4 criteria):**

Score each channel 1-5:

1. **Audience Match** -- Is your ICP actually active here? How concentrated vs. noisy?
2. **Competition Level** -- How saturated is this channel in your category? Lower competition = more opportunity.
3. **Time to Traction** -- How long until this channel produces real leads? (1 = 90+ days, 5 = within 2 weeks)
4. **Founder Advantage** -- Do you have an existing network, credibility, or content asset here?

**Channel options by business type:**

**B2B SaaS founders:**

| Channel | Time to Signal | Best For |
|---------|---------------|---------|
| LinkedIn outbound (personalized) | 2-4 weeks | VP/Director level buyers |
| Content marketing (thought leadership) | 60-90 days | Category creation, inbound |
| Partner / integration ecosystem | 30-60 days | Product-led, adjacent tools |
| Cold email (well-segmented) | 1-3 weeks | High-volume, mid-market |
| Community (Slack groups, forums) | 30-60 days | Niche verticals |

**B2C local / consumer:**

| Channel | Time to Signal | Best For |
|---------|---------------|---------|
| Instagram / TikTok content | 30-60 days | Visual products, lifestyle |
| Local SEO + Google Business Profile | 60-90 days | Search-intent buyers |
| Referral program | Immediate w/ base | High-satisfaction, social products |
| Pop-up / event | Day-of | Place-based trust building |
| Email newsletter | 2-4 weeks | Retention and reactivation |

**Marketplace:**

| Channel | Time to Signal | Best For |
|---------|---------------|---------|
| Direct supply recruitment | Immediate | Cold-start supply side |
| SEO (supply-side pages) | 90+ days | Scalable, long-term demand |
| PR + press | 1-4 weeks | Credibility + demand spike |
| Referral (both sides) | Requires base | Network-effect acceleration |
| Paid demand gen | 1-2 weeks | Fast demand test |

**Step: Build the channel selection matrix**

Evaluate 4-6 relevant channels against all 4 criteria. Sum scores. Recommend the top 1-2 as primary channels. Explicitly name 1 channel to deprioritize and explain why.

**Output: Channel Selection Matrix + Distribution Strategy Brief**

```
## Channel Selection Matrix - [startup_name]

| Channel | Audience Match | Competition | Time to Traction | Founder Advantage | Total |
|---------|---------------|-------------|-----------------|-------------------|-------|
| [Channel 1] | /5 | /5 | /5 | /5 | /20 |
| [Channel 2] | /5 | /5 | /5 | /5 | /20 |
| [Channel 3] | /5 | /5 | /5 | /5 | /20 |

**Primary Channel 1:** [name] - [1-sentence rationale]
**Primary Channel 2:** [name] - [1-sentence rationale]
**Deprioritized:** [name] - [reason]

## Distribution Strategy Brief

**ICP:** [one-line summary of beachhead]
**Primary channels:** [1-2 selected]
**30-day activation:**
- Week 1: [specific first action]
- Week 2: [first outreach or publish]
- Week 3-4: [measure + adjust]

**What channel success looks like in 30 days:** [specific metric threshold]
```

**Facilitated mode challenge prompts:**
- "Which competitor is growing fastest -- and what are they doing that you could do better?"
- "Where does your ICP already go to solve adjacent problems?"
- "What channel gives you 100 conversations in 30 days without paid budget?"

## Write Config

After completing all three sub-activities, update `config.json`:

```json
{
  "icp_segment": "[beachhead segment name and one-line JTBD]",
  "channels_selected": ["[primary channel 1]", "[primary channel 2]"]
}
```

## Config Dependencies

**Reads:** `startup_name`, `problem_statement`, `target_market`, `stage`, `business_type`, `facilitated_mode`
**Writes:** `icp_segment`, `channels_selected`

## Platform Notes

| Platform | Behavior |
|----------|----------|
| Claude Code | Full flow: reads config.json, WebSearch for competitive research, writes icp_segment |
| Claude Desktop | Full flow: WebSearch available for competitive research |
| Claude Cowork | Full flow: founder provides competitive intel manually if no WebSearch |
