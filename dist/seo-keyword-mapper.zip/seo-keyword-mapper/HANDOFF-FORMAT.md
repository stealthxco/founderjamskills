Copied from the founder-setup skill by package-skills.sh. If founder-setup is installed, its copy is the same.

## FOUNDER JAM HANDOFF format

This is the one place the format is defined. Every other skill in the pack reads and writes it.

```
FOUNDER JAM HANDOFF
version: 2
startup_name:
mode: solo | with-sherpa
path: product-positioning | gtm-growth | sales | ops-automation | undecided
stage: idea | pre-revenue | early-revenue
problem_statement:
target_market:
team_size:
traction:
business_type: b2b-saas | services | marketplace | consumer
icp_segment:
top_pains:
hypothesis_selected:
channels_selected:
lead_magnet:
outbound_system:
published_pages:
```

Rules for every skill that touches the block:

- One `key: value` line per field, plain text, no markdown inside the fence.
- `stage` means the startup's stage (idea, pre-revenue, early-revenue). It is not a Founder Jam stage.
- `channels_selected` and `published_pages` are comma-separated on one line.
- Leave a field empty when it is unknown. Never invent a value.
- When a skill finishes, it prints the full block again with its new fields filled in, so the founder always holds the latest version. Keep every field you didn't change. This applies to every founder skill (Understand, Focus, Build, Validate). The sherpa skills read founders' blocks but do not print one back.
- If a founder pastes an older or partial block, use what is there and ask for the rest.
